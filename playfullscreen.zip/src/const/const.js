export const baseurl = "https://api.playfullscreen.a2hosted.com";
// export const baseurl = process.env.BASE_URL || "http://localhost:3001";
export const lightningUrl = "https://lightning.playfullscreen.a2hosted.com";
export const thumbUrl = "https://dashboard.playfullscreen.a2hosted.com";
export const STRIPE_KEY = "pk_test_51L2GBFAM6Vg8cV3xK1WFkm7VXiGpK2SJFgLbO60VFolqK2P8DwwgxySNd3SGBijgnL93uksqcK1WiZnYZgeqLrMV00Xm3utfAB";