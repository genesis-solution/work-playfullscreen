module.exports = { CASTR_API_KEY: "castrkey_746f9270-46d9-11ed-a53f-4302cc64d24c" };
